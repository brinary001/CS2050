#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct Book{
	int bookID;
	char* title;
	bool checkedOut;
	struct Book* next;
}book;

typedef struct BookIds{
	int id;
	struct BookIds* next;
}bookIds;

typedef struct Student{
	char* firstName;
	char* lastName;
	int priority;
	int readingLevel;
	bookIds* wishlist; 
	struct Student* next;
}student;

//Part One
student* buildStudentList(char* studentsFile, student* head);
void printStudents(student* head);
void createPriorityQueue(student* head);

//Part Two
void addWishlist(student* head,char* wishListfile);
book* createBookList(char* bookFile,book* bookHead);
void printBookList(book* bookHead);

//Part Three
void checkOutBooks(student* studentHead, book* bookHead);
book* findBook(book* bookhead, int book_id);

#define NAME 25
#define TITLE 50
int main(int argc, char* argv[]){



	return 0;
}

student* buildStudentList(char* studentsFile, student* head) {

	return NULL;
}
void printStudents(student* head) {

}
void createPriorityQueue(student* head) {

}

void addWishlist(student* head,char* wishListfile) {

}
book* createBookList(char* bookFile,book* bookHead) {
	return NULL;
}
void printBookList(book* bookHead) {

}

void checkOutBooks(student* studentHead, book* bookHead) {

}
book* findBook(book* bookhead, int book_id) {
	return NULL;
}